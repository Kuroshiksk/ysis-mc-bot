# YSIS MC — Painel administrativo + bot Discord

Versão inicial focada em **regras, cargos, canais, avisos e logs**. Pets, banners, molduras, backgrounds e personalização visual ficam para uma próxima versão.

## Funcionalidades do painel

- Login OAuth2 pelo Discord.
- Lista servidores onde o bot já está instalado e a conta tem permissão de administrar.
- Editar, guardar e publicar as regras num canal de texto.
- Criar e apagar cargos; atribuir ou retirar cargo de um membro pelo ID do Discord.
- Criar canais de texto, voz e categorias; renomear, apagar e configurar modo lento.
- Publicar avisos em embed.
- Definir canal para logs de ações administrativas.
- Interface responsiva para telemóvel e computador.

## Comandos slash incluídos

### Regras
- `/regras mostrar` — mostrar as regras guardadas.
- `/regras configurar texto` — atualizar o texto das regras (permissão Gerir servidor).
- `/regras publicar canal` — publicar as regras num canal de texto.
- `/regras canal canal` — definir o canal padrão de regras.

### Cargos
- `/cargo criar nome cor` — criar um cargo; a cor é opcional, exemplo `#5865F2`.
- `/cargo atribuir membro cargo` — atribuir um cargo a um membro.
- `/cargo remover membro cargo` — retirar um cargo de um membro.
- `/cargo apagar cargo` — apagar um cargo.

### Canais
- `/canal criar nome tipo categoria` — criar canal de texto, voz ou categoria; a categoria é opcional.
- `/canal apagar canal` — apagar canal.
- `/canal renomear canal nome` — renomear canal.
- `/canal lentidao canal segundos` — definir modo lento; `0` desativa.

### Administração
- `/aviso canal mensagem` — enviar aviso em embed.
- `/limpar quantidade canal` — apagar de 1 a 100 mensagens recentes (o Discord não permite bulk-delete de mensagens com mais de 14 dias).
- `/logs definir canal` — escolher canal de registos.
- `/logs ver` — mostrar canal de registos atual.
- `/servidor` — mostrar informações básicas do servidor.
- `/ajuda` — mostrar lista de comandos.
- `/painel` — enviar o link do painel administrativo (administradores do servidor).

## Instalação local

1. Instala Node.js 20 ou superior.
2. Extrai os ficheiros e abre um terminal na pasta do projeto.
3. Copia `.env.example` para `.env` e preenche todas as variáveis.
4. Executa `npm install`.
5. Executa `npm run deploy-commands` uma vez para registar os comandos slash.
6. Executa `npm start` para iniciar o bot e o painel na mesma aplicação.

## Configurar o Discord Developer Portal

1. Cria/abre a aplicação em https://discord.com/developers/applications.
2. Em **OAuth2 → General**, adiciona exatamente a URL indicada em `DISCORD_REDIRECT_URI`, por exemplo `https://TEU-APP.up.railway.app/auth/callback`.
3. Copia o **Client ID** e o **Client Secret** para `.env`.
4. Em **Bot**, copia o token para `DISCORD_TOKEN`. Nunca partilhes o token em mensagens, screenshots ou repositórios.
5. Em **OAuth2 → URL Generator**, escolhe os scopes `bot` e `applications.commands`. Para o bot, seleciona as permissões necessárias: View Channels, Send Messages, Embed Links, Manage Roles, Manage Channels, Manage Messages e Read Message History. Usa o link gerado para convidar o bot.
6. Em Server Settings → Roles, coloca o cargo do bot **acima** dos cargos que ele precisa gerir. O bot não consegue gerir cargos acima ou no mesmo nível do próprio cargo.
7. Para atribuir cargos a utilizadores, ativa **Server Members Intent** em Developer Portal → Bot → Privileged Gateway Intents. Reinicia o bot.

## Hospedar no Railway

- Cria um projeto a partir deste repositório/pasta.
- O comando de arranque é `npm start` (o Railway lê isso do `package.json`).
- Adiciona as variáveis de `.env.example` na área Variables do serviço. Define `DASHBOARD_URL` para a URL pública do Railway e `DISCORD_REDIRECT_URI` para `https://SUA-URL/auth/callback`.
- Confere que `DASHBOARD_URL` e `DISCORD_REDIRECT_URI` são iguais às URLs públicas e às configuradas no Developer Portal.
- Depois do primeiro deploy, executa `npm run deploy-commands` no terminal do serviço/Railway Shell, ou localmente com o mesmo `.env`, para registar os comandos.
- O ficheiro `data/config.json` guarda regras e canais. Em produção, usa um Volume persistente montado na pasta `/app/data` para que as configurações não se percam em novos deploys/recriações.

## Segurança e limitações

- Não coloque o token do bot no `index.html`; ele fica apenas no servidor em variáveis de ambiente.
- O utilizador precisa autenticar-se pelo Discord e ter permissão de administração no servidor.
- A versão usa armazenamento JSON local para as configurações e sessões em memória. Para vários processos ou escalabilidade, migra para uma base de dados e store de sessões persistente.
- O bot precisa de permissões adequadas nos canais. Algumas ações também dependem da hierarquia dos cargos.
- Este pacote não está hospedado: é o projeto pronto para configurar no teu ambiente/conta.
